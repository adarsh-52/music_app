enum PlayerState {
  playing,
  paused,
  stopped,
}
